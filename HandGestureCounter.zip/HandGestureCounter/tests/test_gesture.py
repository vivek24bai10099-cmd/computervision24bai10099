from src.gesture_classifier import classify
from src.finger_counter import count_fingers

def test_gesture_labels():
    assert classify(0) == "ZERO"
    assert classify(3) == "THREE"
    assert classify(5) == "FIVE"

def test_invalid_gesture():
    assert classify(8) == "UNKNOWN"

def test_four_fingers():
    class P:
        def __init__(self, x, y): self.x=x; self.y=y
    points = [P(0.5,0.5) for _ in range(21)]
    # index, middle, ring, pinky extended; thumb not extended
    for tip,pip in [(8,6),(12,10),(16,14),(20,18)]:
        points[tip].y=0.2; points[pip].y=0.5
    points[4].x=0.6; points[3].x=0.5
    assert count_fingers(points, "Right") == 4
