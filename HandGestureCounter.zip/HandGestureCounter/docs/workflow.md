# Workflow

1. Accept an image path or webcam flag from the command line.
2. Read the image and validate it.
3. Convert the frame from BGR to RGB for MediaPipe.
4. Detect hand landmarks.
5. Determine extended fingers using landmark positions.
6. Count the raised fingers.
7. Map the count to ZERO–FIVE.
8. Draw landmarks and result text.
9. Save the result in image mode or display the webcam result.
