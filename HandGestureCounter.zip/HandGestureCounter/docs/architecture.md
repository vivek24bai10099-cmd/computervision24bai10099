# Architecture

```text
Input Image / Webcam
        |
        v
  Hand Detector
  (MediaPipe)
        |
        v
 Hand Landmarks
        |
        v
 Finger Counter
        |
        v
 Gesture Classifier
        |
        v
 Console + Annotated Output
```

The system is divided into detection, counting, classification and pipeline modules.
