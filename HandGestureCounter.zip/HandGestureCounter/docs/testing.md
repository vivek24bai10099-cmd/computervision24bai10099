# Testing

Automated tests cover:
- Gesture label mapping.
- Unknown gesture handling.
- Basic finger-counting geometry.

Run:
```bash
pytest -q
```

The image-mode command is the reproducible evaluation path because it does not require a webcam.
