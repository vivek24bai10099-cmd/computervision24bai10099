GESTURES = {
    0: "ZERO", 1: "ONE", 2: "TWO",
    3: "THREE", 4: "FOUR", 5: "FIVE"
}

def classify(count):
    return GESTURES.get(count, "UNKNOWN")
