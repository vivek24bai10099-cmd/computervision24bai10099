from pathlib import Path
import cv2
from .hand_detector import HandDetector
from .finger_counter import count_fingers
from .gesture_classifier import classify

def process_image(image_path, output_dir="output"):
    image = cv2.imread(str(image_path))
    if image is None:
        raise ValueError(f"Could not read image: {image_path}")

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    detector = HandDetector(max_hands=1)
    results = detector.detect(image)
    annotated = detector.draw(image.copy(), results)

    hands = 0
    fingers = 0
    gesture = "NO HAND"

    if results.multi_hand_landmarks:
        hands = len(results.multi_hand_landmarks)
        hand_landmarks = results.multi_hand_landmarks[0]
        handedness = "Right"
        if results.multi_handedness:
            handedness = results.multi_handedness[0].classification[0].label
        fingers = count_fingers(hand_landmarks.landmark, handedness)
        gesture = classify(fingers)

        cv2.putText(
            annotated, f"Gesture: {gesture} | Fingers: {fingers}",
            (20, 45), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2
        )

    cv2.imwrite(str(out / "annotated_result.jpg"), annotated)
    (out / "result.txt").write_text(
        f"Hands detected: {hands}\nRaised fingers: {fingers}\nGesture: {gesture}\n",
        encoding="utf-8"
    )
    return {"hands": hands, "fingers": fingers, "gesture": gesture}

def process_webcam():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("Could not open webcam.")

    detector = HandDetector(max_hands=1, detection_confidence=0.5)
    # Re-create processing object for streaming.
    detector.hands.close()
    detector.hands = detector.mp_hands.Hands(
        static_image_mode=False, max_num_hands=1,
        min_detection_confidence=0.5, min_tracking_confidence=0.5
    )

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        results = detector.detect(frame)
        annotated = detector.draw(frame.copy(), results)

        gesture = "NO HAND"
        fingers = 0
        if results.multi_hand_landmarks:
            hand = results.multi_hand_landmarks[0]
            handedness = results.multi_handedness[0].classification[0].label
            fingers = count_fingers(hand.landmark, handedness)
            gesture = classify(fingers)

        cv2.putText(annotated, f"Gesture: {gesture} | Fingers: {fingers}",
                    (20,45), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
        cv2.imshow("Hand Gesture Counter - press Q to quit", annotated)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
