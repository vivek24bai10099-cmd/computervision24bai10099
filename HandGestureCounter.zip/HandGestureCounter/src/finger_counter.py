def count_fingers(landmarks, handedness="Right"):
    # MediaPipe landmark indexes:
    # thumb: 4, index: 8, middle: 12, ring: 16, pinky: 20
    count = 0

    # For the four non-thumb fingers, a fingertip above its PIP joint
    # represents an extended finger in a mostly upright hand.
    for tip, pip in [(8,6), (12,10), (16,14), (20,18)]:
        if landmarks[tip].y < landmarks[pip].y:
            count += 1

    # Thumb extension is checked horizontally and depends on handedness.
    if handedness == "Right":
        if landmarks[4].x < landmarks[3].x:
            count += 1
    else:
        if landmarks[4].x > landmarks[3].x:
            count += 1

    return count
